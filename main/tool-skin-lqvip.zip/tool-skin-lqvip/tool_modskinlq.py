#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import urllib.request
import zipfile
import shutil
import re

try:
    import pyzstd
except ImportError:
    os.system("pip install pyzstd")
    import pyzstd

API_ENDPOINT = "https://raw.githubusercontent.com/AnorinTool/modskinlq/refs/heads/main/Appearance/aov_skins.json"
API_TOOL_ENC_DEC = "https://github.com/AnorinTool/modskinlq/raw/refs/heads/main/tool-enc-dec/zstd_dict.bin"
API_PREFAB_HERO = "https://github.com/AnorinTool/modskinlq/raw/refs/heads/main/Prefab_Hero/Prefab_Hero.zip"
API_AGES = "https://github.com/AnorinTool/modskinlq/raw/refs/heads/main/Ages/Prefab_Characters/Prefab_Hero/hero.zip"
API_BIENVE = "https://github.com/AnorinTool/modskinlq/raw/refs/heads/main/commonresource/CommonActions.zip"

WORK_DIR = "/storage/emulated/0/Download"
ZIP_FILE_PATH = os.path.join(WORK_DIR, "Prefab_Hero.zip")
AGES_ZIP_PATH = os.path.join(WORK_DIR, "hero.zip")
BIENVE_ZIP_PATH = os.path.join(WORK_DIR, "CommonActions.zip")

EXTRACT_DIR = os.path.join(WORK_DIR, "Prefab_Hero_Extracted")
AGES_EXTRACT_DIR = os.path.join(WORK_DIR, "Ages_Extracted")
BIENVE_EXTRACT_DIR = os.path.join(WORK_DIR, "CommonActions_Extracted")

LOCAL_DICT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "zstd_dict.bin")

OUTPUT_DIR_HERO = os.path.join(WORK_DIR, "FlieModLQ", "Resources", "1.64.1", "Prefab_Characters")
OUTPUT_DIR_FINAL = os.path.join(WORK_DIR, "FlieModLQ", "Resources", "1.64.1", "Ages", "Prefab_Characters", "Prefab_Hero")

ZSTD_LEVEL = 17
MAGIC = b"\x28\xb5\x2f\xfd"
HEADER = b"\x22\x4a\x00\xef"

FALLBACK_DATABASE = {
    "Krixi": {
        "10601": "Công chúa bướm", "10602": "Xứ sở thần tiên", "10603": "Tiệc bãi biển",
        "10604": "Cô tiên thỏ", "10605": "Phó văn nghệ", "10606": "Tiểu yêu nữ",
        "10607": "Hồ thiên nga", "10608": "Thần thoại Hy Lạp", "10609": "Thủy thủ",
        "10611": "Lốc xoáy kinh hoàng Tatsumaki", "10613": "Nàng tiên nổi loạn",
        "10615": "Tiểu hồng mai", "10617": "Quán quân", "10618": "Kimono",
        "10620": "Phù thủy thời không", "10621": "Uyên Ương mộng điệp"
    }
}

def load_zstd_dict():
    try:
        req = urllib.request.Request(API_TOOL_ENC_DEC, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response, open(LOCAL_DICT_PATH, 'wb') as out_file:
            out_file.write(response.read())
    except Exception:
        pass

    if not os.path.isfile(LOCAL_DICT_PATH):
        sys.exit(1)

    with open(LOCAL_DICT_PATH, "rb") as f:
        raw = f.read()
    return pyzstd.ZstdDict(raw, is_raw=True)


def safe_decompress_blob(blob, zdict):
    if blob.startswith(b"<?xml") or blob.startswith(b"<Project>") or blob.startswith(b"\xef\xbb\xbf"):
        return blob, False
    pos = blob.find(MAGIC)
    if pos == -1:
        return blob, False
    try:
        return pyzstd.decompress(blob[pos:], zdict), True
    except Exception:
        return blob, False


def compress_blob(blob, zdict):
    out = bytearray(pyzstd.compress(blob, ZSTD_LEVEL, zdict))
    out[0:0] = len(blob).to_bytes(4, "little", signed=False)
    out[0:0] = HEADER
    return bytes(out)


def normalize_skin_id(skin_id_str):
    skin_id_str = str(skin_id_str).strip()
    if len(skin_id_str) == 5 and skin_id_str[3] == '0':
        return skin_id_str[:3] + skin_id_str[4:]
    return skin_id_str


def fetch_api_database():
    global FALLBACK_DATABASE
    try:
        req = urllib.request.Request(API_ENDPOINT, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as response:
            cloud_data = json.loads(response.read().decode('utf-8'))
            if isinstance(cloud_data, dict) and len(cloud_data) > 0:
                FALLBACK_DATABASE.update(cloud_data)
    except Exception:
        pass

    formatted_db = {}
    for hero_name, skins_dict in FALLBACK_DATABASE.items():
        if not isinstance(skins_dict, dict) or not skins_dict:
            continue
        first_skin_id = str(next(iter(skins_dict.keys())))
        hero_id = first_skin_id[:3]
        display_key = f"{hero_id} - {hero_name}"
        formatted_db[display_key.lower()] = {
            "hero_id": hero_id,
            "hero_name": hero_name,
            "skins": skins_dict,
            "display_key": display_key
        }
    return formatted_db


def download_file(url, save_path):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as response, open(save_path, 'wb') as out_file:
            out_file.write(response.read())
        return True
    except Exception as e:
        print(f"[Lỗi tải tệp] Không thể tải từ {url}: {e}")
        return False


def find_real_hero_folder(extract_root, hero_id, zdict=None):
    target_prefix = str(hero_id).encode("ascii") + b"_"
    for root, dirs, files in os.walk(extract_root):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, 'rb') as f:
                    content = f.read()
                if zdict is not None:
                    content, _ = safe_decompress_blob(content, zdict)
                match = re.search(
                    rb"(?i)prefab_skill_effects/hero_skill_effects/("
                    + re.escape(target_prefix) + rb"[A-Za-z0-9_]+)/",
                    content,
                )
                if match:
                    return match.group(1)
            except Exception:
                continue
    return str(hero_id).encode("ascii") + b"_" + hero_name_global.encode("ascii").lower()


def patch_action_xml_paths(file_bytes, real_hero_folder, selected_5_digit_id, hero_id=None):
    """
    prefab_skill_effects/hero_skill_effects/{hero_folder}/T2_xxx
    → prefab_skill_effects/hero_skill_effects/{hero_folder}/{skin_id}/T2_xxx

    Match moi thu muc bat dau bang {hero_id}_ (khong phu thuoc ten thu muc).
    """
    skin_id = selected_5_digit_id.encode("ascii")

    if hero_id is not None:
        # Match 106_xiaoqiao / 106_XiaoQiao / bat ky 106_*
        folder_pat = re.escape(str(hero_id).encode("ascii")) + rb"_[A-Za-z0-9_]+"
    else:
        folder_pat = re.escape(real_hero_folder)

    pattern = re.compile(
        rb"(?i)(prefab_skill_effects/hero_skill_effects/"
        + folder_pat
        + rb"/)(?:\d{5}/)?([A-Za-z0-9_]+)",
    )

    def repl(m):
        return m.group(1) + skin_id + b"/" + m.group(2)

    file_bytes, n = pattern.subn(repl, file_bytes)
    return file_bytes, n



def patch_skin_audio_events(file_bytes, target_audio_suffix):
    suffix = (
        target_audio_suffix
        if isinstance(target_audio_suffix, bytes)
        else str(target_audio_suffix).encode("ascii")
    )
    event_pattern = re.compile(
        rb"(?<![A-Za-z0-9_])Play_[A-Za-z0-9_]+",
        re.IGNORECASE
    )
    skin_suffix_pattern = re.compile(rb"_skin[0-9]+$", re.IGNORECASE)
    changed = False

    def replace_event(match):
        nonlocal changed
        event_name = match.group(0)
        clean_event = skin_suffix_pattern.sub(b"", event_name)
        new_event = clean_event + suffix
        if new_event != event_name:
            changed = True
        return new_event

    return event_pattern.sub(replace_event, file_bytes), changed


def patch_back_xml_paths(file_bytes, real_hero_folder, selected_5_digit_id):
    """
    Back.xml:

    1) 2 dong GetResource (doan dau):
       .../returncity_holidays/Holiday0/huijidi
       .../returncity_holidays/Holiday0/huicheng_tongyong
       → Prefab_Skill_Effects/hero_skill_effects/{hero}/{id}/huijidi_01
       → Prefab_Skill_Effects/hero_skill_effects/{hero}/{id}/huicheng_tongyong_01

    2) Them 1 cho huicheng_tongyong_01 (doan gan nhat phia duoi):
       .../born_back_reborn/huicheng_tongyong(_01)?
       → Prefab_Skill_Effects/hero_skill_effects/{hero}/{id}/huicheng_tongyong_01

    Khong dung _yu. Prefix viet: Prefab_Skill_Effects/hero_skill_effects/...
    """
    hero = real_hero_folder
    skin_id = selected_5_digit_id.encode("ascii")
    # Dung dung casing theo yeu cau
    base = b"Prefab_Skill_Effects/hero_skill_effects/" + hero + b"/" + skin_id + b"/"

    # ----- 1. Holiday GetResource (tat ca, thuong chi 1 moi loai) -----
    holiday_targets = [
        (
            "GetResource huijidi_01",
            re.compile(
                rb"(?i)Prefab_Skill_Effects/Inner_Game_Effect/returncity_holidays/"
                rb"(?:Holiday\d*/?)huijidi(?:_01)?(?![A-Za-z0-9_])"
            ),
            base + b"huijidi_01",
        ),
        (
            "GetResource huicheng_tongyong_01",
            re.compile(
                rb"(?i)Prefab_Skill_Effects/Inner_Game_Effect/returncity_holidays/"
                rb"(?:Holiday\d*/?)huicheng_tongyong(?:_01)?(?![A-Za-z0-9_])"
            ),
            base + b"huicheng_tongyong_01",
        ),
    ]

    for label, pattern, replacement in holiday_targets:
        file_bytes, n = pattern.subn(replacement, file_bytes)
        print(f"  [Back.xml] {label}: sua {n} cho")

    # ----- 2. Mot cho huicheng_tongyong_01 phia duoi (tongyong born_back) -----
    tongyong_pat = re.compile(
        rb"(?i)prefab_skill_effects/tongyong_effects/tongyong_hurt/born_back_reborn/"
        rb"huicheng_tongyong(?:_01)?(?![A-Za-z0-9_])"
    )
    file_bytes, n = tongyong_pat.subn(base + b"huicheng_tongyong_01", file_bytes, count=1)
    print(f"  [Back.xml] tongyong huicheng_tongyong_01 (gan nhat): sua {n} cho")

    return file_bytes



hero_name_global = "hero"


def run_tool():
    global hero_name_global
    print("=" * 65)
    print(" HỆ THỐNG MOD SKIN AOV - CHUẨN HÓA CẤU TRÚC THEO YÊU CẦU")
    print(" VERSION: RECOMPRESS + BACK-CASING - 2026-10-31f")
    print("=" * 65)

    zdict = load_zstd_dict()
    database = fetch_api_database()

    hero_input = input("\nNhập Tên hoặc ID Tướng (Ví dụ: Krixi hoặc 106): ").strip().lower()
    found_key = None
    for key in database.keys():
        if hero_input in key:
            found_key = key
            break

    if not found_key:
        print(f"[Lỗi] Không tìm thấy tướng '{hero_input}'.")
        return

    hero_info = database[found_key]
    hero_id = hero_info["hero_id"]
    hero_name = hero_info["hero_name"]
    hero_name_global = hero_name

    skin_items = list(hero_info["skins"].items())
    print(f"\nDanh sách Skin của tướng {hero_name}:")
    print("-" * 55)
    for idx, (s_id, s_name) in enumerate(skin_items, 1):
        norm_s_id = normalize_skin_id(s_id)
        print(f"[{idx}] Mã 5 số (Hiệu ứng/Skill): {s_id} | Mã 4 số (Ngoại hình): {norm_s_id} -> {s_name}")
    print("-" * 55)

    try:
        choice_idx = int(input("\nNhập số thứ tự skin muốn chọn (VD: 1, 2, 3...): ").strip())
        if choice_idx < 1 or choice_idx > len(skin_items):
            print("[Lỗi] Số thứ tự bạn chọn không nằm trong danh sách.")
            return
    except ValueError:
        print("[Lỗi] Vui lòng nhập một số nguyên hợp lệ.")
        return

    selected_5_digit_id, skin_name = skin_items[choice_idx - 1]
    selected_5_digit_id = str(selected_5_digit_id).strip()
    selected_4_digit_id = normalize_skin_id(selected_5_digit_id)

    if not selected_5_digit_id.isdigit() or len(selected_5_digit_id) != 5:
        print(f"[Lỗi] ID skin không hợp lệ: {selected_5_digit_id}")
        return

    audio_digit = selected_5_digit_id[-1]

    print(f"\n=> Bạn đã chọn: [{skin_name}]")
    print(f"   + Ngoại hình (Infos): {selected_4_digit_id}")
    print(f"   + Hậu tố Âm thanh mục tiêu: _skin{audio_digit}")

    # ==========================================
    # BƯỚC 1: XỬ LÝ NGOẠI HÌNH (Infos)
    # ==========================================
    print("\n--- [BƯỚC 1] XỬ LÝ NGOẠI HÌNH (Infos) ---")
    if download_file(API_PREFAB_HERO, ZIP_FILE_PATH):
        os.makedirs(EXTRACT_DIR, exist_ok=True)
        with zipfile.ZipFile(ZIP_FILE_PATH, 'r') as zip_ref:
            zip_ref.extractall(EXTRACT_DIR)

        pkg_filename = f"Actor_{hero_id}_Infos.pkg.bytes"
        pkg_source_path = None
        for root, dirs, files in os.walk(EXTRACT_DIR):
            if pkg_filename in files:
                pkg_source_path = os.path.join(root, pkg_filename)
                break

        if pkg_source_path:
            container_extract_dir = os.path.join(WORK_DIR, f"Container_{hero_id}")
            shutil.rmtree(container_extract_dir, ignore_errors=True)
            os.makedirs(container_extract_dir, exist_ok=True)

            with zipfile.ZipFile(pkg_source_path, 'r') as pkg_zip:
                pkg_zip.extractall(container_extract_dir)

            for root, dirs, files in os.walk(container_extract_dir):
                for file in files:
                    if file.endswith("_actorinfo.bytes") or file.endswith(".bytes"):
                        target_binary_path = os.path.join(root, file)
                        with open(target_binary_path, 'rb') as f:
                            raw_blob = f.read()
                        decrypted_data, _ = safe_decompress_blob(raw_blob, zdict)
                        modified_data = decrypted_data

                        norm_target_bytes = selected_4_digit_id.encode('utf-8')
                        for s_id in hero_info["skins"].keys():
                            norm_skin_id = normalize_skin_id(s_id)
                            if norm_skin_id != selected_4_digit_id:
                                src_bytes = norm_skin_id.encode('utf-8')
                                if len(src_bytes) == len(norm_target_bytes) and src_bytes in modified_data:
                                    modified_data = modified_data.replace(src_bytes, norm_target_bytes)

                        final_output_bytes = compress_blob(modified_data, zdict)
                        with open(target_binary_path, 'wb') as f:
                            f.write(final_output_bytes)
                        break

            os.makedirs(OUTPUT_DIR_HERO, exist_ok=True)
            pack_path = os.path.join(OUTPUT_DIR_HERO, pkg_filename)
            with zipfile.ZipFile(pack_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(container_extract_dir):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, container_extract_dir)
                        zipf.write(full_path, rel_path)

            shutil.rmtree(container_extract_dir, ignore_errors=True)
            print(f"[Thành công] Đã xuất ngoại hình: {pack_path}")
        else:
            print(f"[Cảnh báo] Không tìm thấy {pkg_filename} trong gói tải về.")

        shutil.rmtree(EXTRACT_DIR, ignore_errors=True)
        if os.path.exists(ZIP_FILE_PATH):
            os.remove(ZIP_FILE_PATH)
        print("[Dọn dẹp] Đã xóa hoàn toàn Prefab_Hero.zip khỏi thiết bị.")
    else:
        print("[Lỗi] Không tải được dữ liệu ngoại hình. Bỏ qua bước Infos.")

    # ==========================================
    # BƯỚC 2: VÁ HIỆU ỨNG & ÂM THANH (ACTIONS) - DẠNG THÔ
    # ==========================================
    print("\n--- [BƯỚC 2] VÁ GÓI ACTIONS (DẠNG THÔ CHUẨN XÁC) ---")
    if download_file(API_AGES, AGES_ZIP_PATH):
        os.makedirs(AGES_EXTRACT_DIR, exist_ok=True)
        with zipfile.ZipFile(AGES_ZIP_PATH, 'r') as zip_ref:
            zip_ref.extractall(AGES_EXTRACT_DIR)

        actions_pkg_filename = f"Actor_{hero_id}_Actions.pkg.bytes"
        actions_source_path = None

        for root, dirs, files in os.walk(AGES_EXTRACT_DIR):
            if actions_pkg_filename in files:
                actions_source_path = os.path.join(root, actions_pkg_filename)
                break

        if actions_source_path:
            actions_container_dir = os.path.join(WORK_DIR, f"Container_Actions_{hero_id}")
            shutil.rmtree(actions_container_dir, ignore_errors=True)
            os.makedirs(actions_container_dir, exist_ok=True)

            with zipfile.ZipFile(actions_source_path, 'r') as pkg_zip:
                pkg_zip.extractall(actions_container_dir)

            real_hero_folder = find_real_hero_folder(actions_container_dir, hero_id, zdict)
            print(f"[Nhận diện] Thư mục tướng thực tế trong gói: {real_hero_folder.decode('ascii')}")

            target_audio_suffix = f"_skin{audio_digit}".encode("ascii")

            files_modified_count = 0
            for root, dirs, files in os.walk(actions_container_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'rb') as f:
                            raw_content = f.read()

                        decrypted_data, was_compressed = safe_decompress_blob(raw_content, zdict)
                        file_bytes = decrypted_data
                        file_changed = False

                        patched_effect_data, n_paths = patch_action_xml_paths(file_bytes, real_hero_folder, selected_5_digit_id, hero_id=hero_id)
                        if n_paths:
                            file_changed = True
                            print(f" -> [Actions] {os.path.relpath(file_path, actions_container_dir)}: chen ID vao {n_paths} path")
                        file_bytes = patched_effect_data

                        file_bytes, audio_changed = patch_skin_audio_events(file_bytes, target_audio_suffix)
                        if audio_changed:
                            file_changed = True

                        if file_changed:
                            files_modified_count += 1
                            # Ma hoa lai (HEADER + size + zstd dict)
                            file_bytes = compress_blob(file_bytes, zdict)
                            print(f" -> [Actions] Da va + ma hoa lai: {os.path.relpath(file_path, actions_container_dir)}")
                            with open(file_path, 'wb') as f_out:
                                f_out.write(file_bytes)
                        else:
                            with open(file_path, 'wb') as f_out:
                                f_out.write(raw_content)

                    except Exception as e:
                        print(f" -> [Lỗi xử lý] {file}: {e}")

            os.makedirs(OUTPUT_DIR_FINAL, exist_ok=True)
            final_actions_pkg_path = os.path.join(OUTPUT_DIR_FINAL, actions_pkg_filename)

            with zipfile.ZipFile(final_actions_pkg_path, 'w', zipfile.ZIP_STORED) as zipf:
                for root, dirs, files in os.walk(actions_container_dir):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, actions_container_dir)
                        zipf.write(full_path, rel_path)

            shutil.rmtree(actions_container_dir, ignore_errors=True)
            print(f"[Thành công] Đã xuất gói Actions: {final_actions_pkg_path}")
            print(f"             Số file đã vá: {files_modified_count}")
        else:
            print(f"[Cảnh báo] Không tìm thấy {actions_pkg_filename} trong gói tải về.")

        shutil.rmtree(AGES_EXTRACT_DIR, ignore_errors=True)
        if os.path.exists(AGES_ZIP_PATH):
            os.remove(AGES_ZIP_PATH)
    else:
        print("[Lỗi] Không tải được dữ liệu Actions.")

    # ==========================================
    # BƯỚC 3: XỬ LÝ HIỆU ỨNG BIẾN VỀ (CommonActions.pkg.bytes) - DẠNG THÔ
    # ==========================================
    print("\n--- [BƯỚC 3] XỬ LÝ BIẾN VỀ COMMMONACTIONS (DẠNG THÔ) ---")
    if download_file(API_BIENVE, BIENVE_ZIP_PATH):
        shutil.rmtree(BIENVE_EXTRACT_DIR, ignore_errors=True)
        os.makedirs(BIENVE_EXTRACT_DIR, exist_ok=True)

        with zipfile.ZipFile(BIENVE_ZIP_PATH, 'r') as zip_ref:
            zip_ref.extractall(BIENVE_EXTRACT_DIR)

        # Dùng đúng thư mục nội bộ đã nhận diện từ gói Actions ở Bước 2
        # (ví dụ 106_xiaoqiao), không dò lại từ tên hiển thị như 106_krixi.
        if "real_hero_folder" not in locals() or not real_hero_folder:
            print("[Cảnh báo] Chưa nhận diện được thư mục nội bộ từ Actions; không thể vá Back.xml chính xác.")
            real_hero_folder = None

        back_xml_found = False

        for root, dirs, files in os.walk(BIENVE_EXTRACT_DIR):
            for file in files:
                if file.lower() == "back.xml":
                    src_file_path = os.path.join(root, file)
                    try:
                        with open(src_file_path, 'rb') as f:
                            raw_xml_bytes = f.read()

                        if real_hero_folder is None:
                            print(" -> [Back.xml] Bỏ qua vì chưa xác định được thư mục tướng thực tế.")
                            continue

                        decrypted_xml, was_compressed = safe_decompress_blob(raw_xml_bytes, zdict)
                        patched_xml_bytes = patch_back_xml_paths(decrypted_xml, real_hero_folder, selected_5_digit_id)

                        # Ghi Back.xml ở dạng thô, KHÔNG mã hóa/nén lại bằng zstd_dict.bin
                        # Nếu đầu vào là ZSTD thì chỉ giải nén để đọc và vá; đầu ra vẫn là XML thô.
                        with open(src_file_path, 'wb') as f_out:
                            f_out.write(patched_xml_bytes)

                        back_xml_found = True
                        print(f" -> [Back.xml] Da va va xuat dang tho (khong ma hoa ZSTD): {src_file_path}")
                    except Exception as e:
                        print(f" -> [Lỗi xử lý back.xml]: {e}")

        if back_xml_found:
            os.makedirs(OUTPUT_DIR_FINAL, exist_ok=True)
            final_common_pkg_path = os.path.join(OUTPUT_DIR_FINAL, "CommonActions.pkg.bytes")

            with zipfile.ZipFile(final_common_pkg_path, 'w', zipfile.ZIP_STORED) as zipf:
                for root, dirs, files in os.walk(BIENVE_EXTRACT_DIR):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, BIENVE_EXTRACT_DIR)
                        zipf.write(full_path, rel_path)

            print(f"[Thành công] Đã xuất gói CommonActions tại: {final_common_pkg_path}")
        else:
            print("[Cảnh báo] Không tìm thấy tệp back.xml bên trong gói CommonActions.")

        shutil.rmtree(BIENVE_EXTRACT_DIR, ignore_errors=True)
        if os.path.exists(BIENVE_ZIP_PATH):
            os.remove(BIENVE_ZIP_PATH)
    else:
        print("[Lỗi] Không tải được gói CommonActions.zip từ máy chủ.")

    print("\n" + "=" * 65)
    print(" [HOÀN TẤT] CẤU TRÚC ĐƯỜNG DẪN ĐÃ CHUẨN XÁC THEO YÊU CẦU!")
    print(f"- Thư mục Ngoại hình: {OUTPUT_DIR_HERO}")
    print(f"- Thư mục Actions & CommonActions: {OUTPUT_DIR_FINAL}")
    print("=" * 65)


if __name__ == "__main__":
    run_tool()
